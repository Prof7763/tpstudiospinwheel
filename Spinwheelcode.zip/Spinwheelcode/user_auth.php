<?php
session_start();

$usersFile = 'users.json';

// Load existing users from file or initialize empty array
if (file_exists($usersFile)) {
    $usersData = json_decode(file_get_contents($usersFile), true);
    if (!is_array($usersData)) {
        $usersData = [];
    }
} else {
    $usersData = [];
}

function saveUsers($users, $file) {
    file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));
}

function redirectWithMessage($message, $type = 'error') {
    $_SESSION['message'] = $message;
    $_SESSION['message_type'] = $type;
    header('Location: login.html');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        // Collect and sanitize input
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $phone = trim($_POST['phone'] ?? '');

        // Basic validation
        if (!$firstName || !$lastName || !$email || !$username || !$password || !$phone) {
            redirectWithMessage('All fields are required for registration.');
        }

        // Check if username or email already exists
        foreach ($usersData as $user) {
            if ($user['username'] === $username) {
                redirectWithMessage('Username already exists. Please choose another.');
            }
            if ($user['email'] === $email) {
                redirectWithMessage('Email already registered. Please use another.');
            }
        }

        // Hash the password
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Add new user
        $usersData[] = [
            'first_name' => $firstName,
            'last_name' => $lastName,
            'email' => $email,
            'username' => $username,
            'password_hash' => $passwordHash,
            'phone' => $phone
        ];

        // Save users
        saveUsers($usersData, $usersFile);

        // Redirect to login.html after successful registration
        header('Location: login.html');
        exit();

    } elseif ($action === 'login') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$username || !$password) {
            redirectWithMessage('Username and password are required for login.');
        }

        // Find user by username
        $foundUser = null;
        foreach ($usersData as $user) {
            if ($user['username'] === $username) {
                $foundUser = $user;
                break;
            }
        }

        if (!$foundUser) {
            redirectWithMessage('Invalid username or password.');
        }

        // Verify password
        if (!password_verify($password, $foundUser['password_hash'])) {
            redirectWithMessage('Invalid username or password.');
        }

        // Successful login, redirect to index.html
        header('Location: index.html');
        exit();

    } else {
        redirectWithMessage('Invalid action.');
    }
} else {
    redirectWithMessage('Invalid request method.');
}
?>
