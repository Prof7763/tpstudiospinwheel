<?php
// result.php - Receives spin result and sends it to Telegram

// Telegram Bot API token and chat ID placeholders
$botToken = 'YOUR_TELEGRAM_BOT_TOKEN_HERE';
$chatId = 'YOUR_TELEGRAM_CHAT_ID_HERE';

// Get the spin result from POST data
$spinResult = isset($_POST['spinResult']) ? $_POST['spinResult'] : 'No result received';

// Prepare the message to send
$message = "New Spin Result: " . $spinResult;

// Telegram API URL
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";

// Prepare POST fields
$postFields = [
    'chat_id' => $chatId,
    'text' => $message
];

// Use cURL to send the message
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

// Optionally, you can return a JSON response
header('Content-Type: application/json');
echo json_encode(['status' => 'success', 'response' => $response]);
?>
